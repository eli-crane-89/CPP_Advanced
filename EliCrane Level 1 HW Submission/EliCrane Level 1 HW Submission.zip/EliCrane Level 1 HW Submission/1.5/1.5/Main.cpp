#include "Exercise1.hpp"
#include "Exercise2.hpp"
#include "Exercise3.hpp"
#include "Exercise4.hpp"
#include "Exercise5.hpp"

int main() {

	Exercise1();
	Exercise2();
	Exercise3();
	Exercise4();
	Exercise5();

	return 0;
}