#include <iostream>

#include "Exercise1.hpp"
#include "Exercise2.hpp"

int main() {

	Exercise1();
	Exercise2();

	return 0;
}