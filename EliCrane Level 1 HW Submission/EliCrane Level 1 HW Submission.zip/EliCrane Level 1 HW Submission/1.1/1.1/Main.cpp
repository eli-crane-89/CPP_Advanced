#include "Exercise1.hpp"
#include "Exercise2.hpp"

using namespace std;

int main() {

	Exercise1();
	Exercise2();

	return 0;
}




