#ifndef ADDCODE_HPP
#define ADDCODE_HPP

class TestClass {};

#endif